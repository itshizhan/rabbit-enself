<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'rabbit-ohis'
}
</script>

<style lang="scss">
  @import "./assets/css/main.css";
  @import "./assets/css/color-dark.css";     /*深色主题*/
</style>
